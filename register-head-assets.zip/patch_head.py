# Run once from the repo root: python3 patch_head.py
# Inserts favicon + social-card tags into build.py's page template, right after <head>.
import re, sys
p = "build.py"
s = open(p).read()
marker = "<!-- calyx-head-tags -->"
if marker in s:
    print("Already patched."); sys.exit(0)
tags = marker + """
<meta name="description" content="Adopted and proposed data center rules, each linked to its source document.">
<meta property="og:type" content="website">
<meta property="og:url" content="https://register.calyxos.ai/">
<meta property="og:title" content="Calyx Data Center Register">
<meta property="og:description" content="Adopted and proposed data center rules, each linked to its source document.">
<meta property="og:image" content="https://register.calyxos.ai/og-image.png">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32.png">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
"""
if "{" in tags or "}" in tags:
    sys.exit("unexpected braces")
n = s.count("<head>")
if n == 0:
    sys.exit("No <head> found in build.py. Paste the head section of build.py into chat instead.")
s = s.replace("<head>", "<head>\n" + tags, 1)
open(p, "w").write(s)
print(f"Patched build.py ({n} <head> found; first one updated).")
